insert into Student values('1003','HARSH','EEE',30);

insert into Student values('1004','VAIDYA','AI/ML',24);